import { Component } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label, Color } from 'ng2-charts';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators'

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})

export class BarChartComponent {

  public barChartOptions: ChartOptions = {
    responsive: true,
    scales: {
        xAxes: [{
          gridLines: {
            display: true
          },    
          stacked: true,
          ticks: {
            beginAtZero: false,
          },
        }],
        yAxes: [{
          gridLines: {
            display: true
          },    
          stacked: true,
          ticks: {
            beginAtZero: false,
          },
        }]
    },
    tooltips: {
      mode: 'index',
    }
  };
  public barChartColors: Color[] = [
    {
      backgroundColor: ["#1E90FF","#00FFFF","#FF8C00","#FA8072"],
      borderColor: ['rgba(0,0,0,0)','rgba(0,0,0,0)','rgba(0,0,0,0)','rgba(0,0,0,0)']
    }
  ];
  
  public barChartLabels: Label[] = ['Home & Utilities', 'Travel ', 'Ride Sharing', 'Drink'];
  public barChartType: ChartType = 'horizontalBar';
  public barChartLegend = true;
  public barChartPlugins = [];

  public barChartData: ChartDataSets[] = [
    { data: [3800, 3086, 2400, 3800], label: 'Catagory' },
  ];


  public subbarChartLabels: Label[] = ['Drink', 'Rent', 'Groeries'];
  public subbarChartData: ChartDataSets[] = [
    { data: [1000, 2450, 350], label: 'Sub Catagory' },
  ];


  catagorys : any[];
  subcatagorys : any[];


      constructor(private http: HttpClient) {

        let curl = 'http://65.1.73.181:3001/api/v1.0/master/CategoryStatistics';
        let subcurl = 'http://65.1.73.181:3001/api/v1.0/master/SubCategoryStatistics';


        this.http.post<any>(curl,{}).pipe(map(data => { return data.responseData }))
        .subscribe(data => {
          this.catagorys = data
  
          console.log("this.catagorys.........",this.catagorys)
      })


      this.http.post<any>(subcurl,{"CategoryId":1}).pipe(map(data => { return data.responseData }))
        .subscribe(data => {
          this.subcatagorys = data
          console.log("this.subcatagorys.........",data)
      })

       }

  ngOnInit() {


  }
  
 



}
